#!/bin/bash
# Usage
function usage(){
  echo "
Usage:
  bash $0 [option] <submission-file> <input-dir> <output-dir> [<task-specific-parameters>]

Description:
  Executes a participant's submission for a task. The submission is expected to
  take the input directory as a corpus

Options:
  -h | --help           Displays this help

Parameter:
  <submission-file>     Contains user credentials and the software command
  <input-dir>           Name of the input directory where a task's corpus is
                        located in the shared folder inside the virtual machine.
  <output-dir>          Name of the output directory where the software stores
                        its results. Inside the virtual machine
  <optional-parameters> Additional task-specific parameters, such as an access
                        token for source retrieval, or language and genre tags
                        for author identification. The parameters must be
                        formatted as follows:
                          'token=my-token;language=en;genre=reviews'

Examples:
  bash run-software.sh 'submission-text-alignment.txt' 'pan14-text-alignment-mini-corpus' 'test-run'
  bash run-software.sh 'submission-source-retrieval.txt' 'pan14-source-retrieval-mini-corpus' 'test-run'
  "
  exit 1
}

if [ "$1" == "--help" ] || [ "$1" == "-h" ]; then
  usage
fi

# check number of parameters
if [ $# -ne 4 ] && [ $# -ne 3 ]; then
  echo "ERROR: wrong amount of parameters."
  usage
fi

submissionFile=$1
timestamp=$( date +%F-%H-%M-%S )


# check if submission file exists
if [ ! -e $submissionFile ]
then
    echo "ERROR: $submissionFile does not exist."
    usage
fi

inputDirName=$2
outputDirName=$3

# check for additional parameters
if [ $# -eq 4 ]; then
  additonalParameters=$4
  # evaluate additional Parameters
  eval $additonalParameters
fi



# include user specific data
source $submissionFile

# define shared folder and output directory according os
if [ "$os" = "ubuntu" ]; then
  sharedFolder="/media/pan14-training-corpora/"
  outputRunDir="/tmp/$outputDirName/$timestamp"
elif [ "$os" = "windows" ]; then
  sharedFolder="//VBOXSRV/pan14-training-corpora/"
  outputRunDir="C:/Windows/Temp/$outputDirName/$timestamp"
fi
outputDir="$outputRunDir/result"


# define input directory
inputDir="$sharedFolder$inputDirName"
echo -e "# $user@$host: input directory $inputDir"

# include user specific data
source $submissionFile

# execute program on vm
echo -e "# $user@$host: establishing SSH connection and executing command..."
echo -e "\t$cmd"
sshpass -p $userpw ssh $user@$host -p $sshport -o StrictHostKeyChecking=no -t "mkdir -p $outputDir; cd $workingDir; (echo -e '$cmd\n\n' && $cmd) 1> $outputRunDir/stdout.txt 2> $outputRunDir/stderr.txt"

# copy outputDir from vm to localhost
echo -e "# $user@$host: copying $outputDir from VM..."
mkdir -p $inputDirName/$outputDirName
sshpass -p $userpw scp -r -P $sshport $user@$host:$outputRunDir $inputDirName/$outputDirName

# remove outputDir on vm
echo -e "# $user@$host: removing $outputDir from VM..."
sshpass -p $userpw ssh $user@$host -p $sshport -o StrictHostKeyChecking=no -t "rm -r $outputRunDir"

echo -e "# $user@$host: done."
