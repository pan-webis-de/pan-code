PAN Software Submission Readiness Tester
========================================

This package contains a bash script that helps you to check whether your
software is submission-ready after deploying it into your virtual machine.
If the script completes without errors, and if the output of your software
is as expected, chances are high there will be no further errors when we
run your software ourselves for evaluation.

We ask you to run your software using our script and to verify that it works
before submitting it.

The script is found in run-software.sh, and it works in three basic steps:

  1. A submission-*.txt file is loaded where user-specific variables are set.
     This file includes the command to call your software.

  2. An ssh connection is established to your virtual machine, and the command
     to execute your software is fired.

  3. The output of your software is stored in a pre-specified directory and
     then downloaded to your machine. Afterwards, the output is deleted from
     the virtual machine to keep it clean from clutter.


How to set up your software?
----------------------------

First deploy your software to your virtual machine and make sure it works.

Second, to set up the submission tester for your software, please open the
submission-template.txt and fill in the variables found there, such as
<user name>, <password>, and <host> of your virtual machine as well as the
<working director> and the <command> to run your software.


How to specify the command to run your software in the submission-*.txt file?
-----------------------------------------------------------------------------

The <command> of your software must include the mandatory arguments that are
specified on your task's web page in the submisssion box. For example, for
source retrieval the corresponding entry may look as follows:

  cmd="python pan12-source-retrieval-baseline.py $inputDir $outputDir $token"

The mandatory parameters shall be specified as bash variables:

  $inputDir      The path to the directory where the input corpus is located.
  $outputDir     The path to the existing, empty directory where your software
                 shall store its output.
  
Moreover, you should specify additional variables as required by your
respective task, such as
  
  $token         Source Retrieval: access token for ChatNoir.
  $language      Author Identification/Profiling: language of the input corpus.
  $genre         Author Identification/Profiling: genre of the input corpus.
  
These variables will be filled in by run-software.sh.


How to execute the run-software.sh script?
------------------------------------------

If you have set up your own submission.txt file, execute the run-software.sh
using the following command:

  bash run-software.sh <submission-file> <input-dir-name> <output-dir-name> [<task-specific-parameters>]

where
  
  <submission-file>            Path to the submission.txt file.
  <input-dir-name>             The name of the input corpus found in the shared
                               folders inside your virtual machine.
  <output-dir-name>            The name of the output directory, which will be
                               located in the temp directory inside your virtual
                               machine.
  [<task-specific-parameters>] Any of the above task-specific parameters, which
                               are encoded semicolon-separated list of key-value
                               pairs:
                                 
                                 'language=en;genre=reviews'


Are there examples?
-------------------

The submission-example-*.txt files enclosed in this archive give an idea of
how to specify the command. If you fill in the user credential of your virtual
machine into these files, you can immediately execute the baseline softwares
on the pan14-*-mini-corpora that are mounted into your virutal machine.

